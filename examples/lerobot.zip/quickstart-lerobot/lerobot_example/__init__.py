"""lerobot_example: A Flower / Hugging Face LeRobot app."""
